<script async defer
  src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCzLzsP3xXR3E20w6iXfRH26HASyRq8GlI&callback=initMap">
</script>
